package com.zeus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootintercephterApplicationTests {

	@Test
	void contextLoads() {
	}

}
