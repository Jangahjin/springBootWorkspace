package com.zeus.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zeus.dto.Address;
import com.zeus.dto.BoardDTO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class TextController {

    // 2번방
    @GetMapping(value = "/Text/posthome")
    public String posthome() {
        return "/Text/posthome";
    }

    @RequestMapping(value = "/Text/gohome1", method = RequestMethod.POST)
    public String gohome(Model model, @ModelAttribute  BoardDTO bd) {
        log.info("/Text/gohome1 userId =" + bd.toString());
        if (bd.getHobby() != null) {
        	log.info("bd.getHobby().size() =" + bd.getHobby().size());
			
		}
        
        return "/Text/gohome1";
    }
    
    @RequestMapping(value = "/Text/gohome1", method = RequestMethod.GET)
    public ArrayList<Address> gohomeGet(Model model, @ModelAttribute  BoardDTO bdo) {
    	ArrayList<Address> addressList = bdo.getAddress();
        log.info("/Text/gohome1 userId =" + addressList.toString());
       
        
        return addressList;
    }
}
