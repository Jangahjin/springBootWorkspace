<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<form action="/Text/gohome1" method="post">
		postCode: <input type="text" name="address.postCode[0]" /><br> 
		location: <input type="text" name="address.location[0]" /><br> 
		
		postCode: <input type="text" name="address.postCode[1]" /><br> 
		location: <input type="text" name="address.location[1]" /><br> 
		<input type="submit" value="/Text/gohome1 get방식">
	</form>
</body>
</html>